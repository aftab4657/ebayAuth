<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        <?php if(session()->has('notice')): ?>
            ShopifyApp.flashNotice("<?php echo e(session('notice')); ?>");
        <?php endif; ?>

        <?php if(session()->has('error')): ?>
            ShopifyApp.flashError("<?php echo e(session('error')); ?>");
        <?php endif; ?>
    });
</script><?php /**PATH C:\xampp\htdocs\test-app\vendor\ohmybrew\laravel-shopify\src\ShopifyApp/resources/views/partials/flash_messages.blade.php ENDPATH**/ ?>