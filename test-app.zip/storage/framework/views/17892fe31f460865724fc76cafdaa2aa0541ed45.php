<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('shopify-app.app_name')); ?></title>

        <?php echo $__env->yieldContent('styles'); ?>
    </head>

    <body>
        <div class="app-wrapper">
            <div class="app-content">
                <main role="main">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
        </div>

        <?php if(config('shopify-app.esdk_enabled')): ?>
            <script src="https://cdn.shopify.com/s/assets/external/app.js?<?php echo e(date('YmdH')); ?>"></script>
            <script type="text/javascript">
                ShopifyApp.init({
                    apiKey: '<?php echo e(config('shopify-app.api_key')); ?>',
                    shopOrigin: 'https://<?php echo e(ShopifyApp::shop()->shopify_domain); ?>',
                    debug: false,
                    forceRedirect: true
                });
            </script>

            <?php echo $__env->make('shopify-app::partials.flash_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\test-app\vendor\ohmybrew\laravel-shopify\src\ShopifyApp/resources/views/layouts/default.blade.php ENDPATH**/ ?>