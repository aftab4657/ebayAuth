<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\EbayProductsModel;
use Faker\Generator as Faker;

$factory->define(EbayProductsModel::class, function (Faker $faker) {
    return [
        //
    ];
});
