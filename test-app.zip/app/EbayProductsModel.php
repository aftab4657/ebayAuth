<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EbayProductsModel extends Model
{
    //
}
