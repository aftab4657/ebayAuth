<?php

namespace App\Http\Controllers;

use App\EbayProductsModel;
use Illuminate\Http\Request;

class EbayProductsModelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\EbayProductsModel  $ebayProductsModel
     * @return \Illuminate\Http\Response
     */
    public function show(EbayProductsModel $ebayProductsModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\EbayProductsModel  $ebayProductsModel
     * @return \Illuminate\Http\Response
     */
    public function edit(EbayProductsModel $ebayProductsModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\EbayProductsModel  $ebayProductsModel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EbayProductsModel $ebayProductsModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\EbayProductsModel  $ebayProductsModel
     * @return \Illuminate\Http\Response
     */
    public function destroy(EbayProductsModel $ebayProductsModel)
    {
        //
    }
}
