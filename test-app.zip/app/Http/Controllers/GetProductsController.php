<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use OhMyBrew\ShopifyApp\Facades\ShopifyApp;
use Log;

class GetProductsController extends Controller
{
    public function get_ebay_products(){
        $AuthToken="AgAAAA**AQAAAA**aAAAAA**KfudXA**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wFk4aiCJmGoQSdj6x9nY+seQ**OvYEAA**AAMAAA**JQO+MOY1E+STcnzozp25CBZcr6326eiKm5GJ8S4oIV4A2/irlT4ucy+jvLWg8e2K5mG2ojMivisKuAwk0EfJ6rszI3ulr6JKDpMjjDnaGEbXb1whK5N0OUfg9NANEMz+LK4cTDBKRY4rpvYkWOOvci1iGdvePZrP07QNjODOJo5BJYulpPINa4TKRNbSWGbJogQh7VykLvYNxpofJJCfMurQxoWGzXCSvNahh34qXe2dr9Fb75Yljvhd2FSkqwGNSkOm23h3sWQk3C4by0SOq2LG+l57zPv/9wnNpVp035tm4/FiYsVDh45myrfRy2riY4SsE233u8mhZMyA5M7gAAn3lSS4gC0zWic1sDN6WjRLFvs18TR071ErZbmN1UdSVPRfZnYmEpkRICsha6E8RiHUjzq1MMAeES6TjqSkIdq5iGKWX/FAFLVMOsWqmyHY9uoPOkrdtNY9W8bcigNBEObivxaZTAUdUAeRa0Q+Lko2dx408QTzehwsq/HgKzzXnZI2ZHnrHgYnXWw3Z1h0IrAh7xNmSQLj9DYwIkGG3dcEYCbpVWYp0Z90Fj1MKo+O/yndQmt8wh2hqUZdXFlkyaLUYh/PD08VBSOruGyRckkKfB9mUfPUozSBNtlhyfnqg41pstoIxj7l2OsIP4TO73+3BMnMNvGSsIFxKZ8E7rrfPygj/KOoD7MqanryygLremOKol/rzKTQgrqCsX/GJ+lcYx8fV3es9qGIa+u10W4auKwbUETQnFIhYc8rihZa";

        $runame = "Th_c_L__B_-ThcLB-SynEbay-S-swfednxx";
        $xml =  "<?xml version='1.0' encoding='utf-8'
        <GetMyeBaySellingRequest xmlns='urn:ebay:apis:eBLBaseComponents'>
           <RequesterCredentials>
             <eBayAuthToken>".$AuthToken."</eBayAuthToken>
           </RequesterCredentials>
           <ErrorLanguage>en_US</ErrorLanguage>
           <WarningLevel>High</WarningLevel>
           <DetailLevel>ReturnAll</DetailLevel>
           <ActiveList>
          
            
          </ActiveList>
             <SoldList>
            <Include>false</Include>
          </SoldList>
         
         </GetMyeBaySellingRequest>";
        $headers = array(
                    'Content-Type: text/xml',
                    'X-EBAY-API-COMPATIBILITY-LEVEL: 967',
                    'X-EBAY-API-CALL-NAME:GetMyeBaySelling',
                    'X-EBAY-API-SITEID: 0'
        );

// Curl Request to fetch data from ebay store
        $url = 'https://api.sandbox.ebay.com/ws/api.dll';      
        // $ch = curl_init();
        // curl_setopt($ch, CURLOPT_URL, $url);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE);
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        // curl_setopt($ch, CURLOPT_POSTFIELDS,$xml);        
        // curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        // $result = curl_exec($ch);  
        // curl_close($ch);
        // $result_array=simplexml_load_string($result);


// Query from database
        $shops = DB::table('shops')->get();



// Below code will print Shopify Store information
        // $shp = ShopifyApp::shop();
        // Log::info('This is the Shop Object: '.print_r($shp,true));
        // print_r($shp);
        // return;



// API REQUEST TO FETCH PRODUCT FROM SHOPIFY STORE
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 9999999);
        $product = "{
            'product': {
              'title': 'Burton Custom Freestyle 151',
              'body_html': '<strong>Good snowboard!</strong>',
              'vendor': 'Burton',
              'product_type': 'Snowboard',
              'tags': 'Barnes & Noble, John's Fav, \'Big Air\''
            }
          }";
        $shop = ShopifyApp::shop();
        $request = $shop->api()->rest('POST', '/admin/products.json',);
        echo "<pre>";
        print_r($request);
        echo "</pre>"; 
        return;


        return view("welcome", ['shops' => $result_array]);
    }
}